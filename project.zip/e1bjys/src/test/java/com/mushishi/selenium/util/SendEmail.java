package com.mushishi.selenium.util;


public class SendEmail {
/*	public static void sendToEmail(String content){
		SimpleEmail email = new SimpleEmail();
		email.setHostName("smtp.163.com");
		email.setAuthentication("mushishi_xu@163.com", "xu221168");
		try {
			email.setFrom("mushishi_xu@163.com");
			email.addTo("609037724@qq.com");
			email.setSubject("selenium自动化测试邮件");
			email.setContent(content, "text/html;charset=utf-8");
			email.send();
		} catch (EmailException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e);
		}
	}
	public static void main(String[] args){
		sendToEmail("sssssddddd");
	}*/
}
